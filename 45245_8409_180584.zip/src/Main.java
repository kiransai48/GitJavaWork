import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws NumberFormatException, ParseException {
	
	 Scanner s= new Scanner(System.in);
	 ArrayList<TicketBooking> li= new ArrayList<TicketBooking>();
	 System.out.println("Enter the number of bookings:");
	 int m= Integer.parseInt(s.nextLine());
	 System.out.println("Enter the booking details:");
	 for(int i=0;i<m;i++)
	 {
		 String e= s.nextLine();
		 String ev[]= e.split("-");
		 TicketBooking t= new TicketBooking(ev[0],Double.parseDouble(ev[1]),new SimpleDateFormat("dd/mm/yyyy").parse(ev[2]),ev[3]);
		 li.add(t);
	 }
	 System.out.println("Enter a type:\r\n1.JSON\r\n2.CSV");
	 int se= Integer.parseInt(s.nextLine());
	 ExportBooking eb= new ExportBooking();
	 if(se==1)
	 {
		 System.out.println("[");
		 eb.exportJSON(li);
		 System.out.print("\r\n]");
	 }
	 else if(se==2)
	 {
		 System.out.println("customer,price,bookingTime,stageEventShow");
		 eb.exportCSV(li);
	 }
	 else
	 {
		 System.out.println("Invalid Input");
	 }

	}

}
