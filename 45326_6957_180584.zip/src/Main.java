import java.util.Scanner;
import java.io.InputStream;
public class Main
{
	public static void main(String[] args)
	{
	String s1="";		
	String s2="";
	int number;
	char paid;
	double money;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the name of the event");
	s1=sc.nextLine();
	System.out.println("Enter the type of the event");
	s2=sc.nextLine();
	System.out.println("Enter the number of people expected");
	number=sc.nextInt();
	System.out.println("Is it a paid entry? (Type Y or N)");
	paid=sc.next().charAt(0);
	System.out.println("Enter the projected expenses (in lakhs) for this event");
	money=sc.nextDouble();
	
	System.out.println("Event Name : "+s1);
	System.out.println("Event Type : "+s2);
	System.out.println("Expected Count : "+number);
	System.out.println("Paid Entry : "+paid);
	System.out.println("Projected Expense : "+money+"L");
}
}

