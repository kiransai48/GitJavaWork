interface Notification {
	void notificationBySms();
	void  notificationByEmail();
    void notificationByCourier();
}
