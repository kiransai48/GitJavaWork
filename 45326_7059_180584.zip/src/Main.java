import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
	public static void main(String[] args)
	{
		double basicsalary, grosssalary, HRA, DA;
		Scanner sc= new Scanner(System.in);
		basicsalary=sc.nextDouble();
		if (basicsalary<15000)
		{
			HRA=0.15*basicsalary;
			DA=0.90*basicsalary;
		}
		else
		{	
			HRA=5000;
			DA=0.98*basicsalary;
		}

		grosssalary=basicsalary+HRA+DA;
		DecimalFormat df=new DecimalFormat("#####.00");
		System.out.println(df.format(+grosssalary));
	}

}
