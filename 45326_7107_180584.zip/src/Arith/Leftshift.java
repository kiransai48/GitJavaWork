package Arith;

public class Leftshift {
	
	/**
	 * @param args
	 */

	public static void main(String[] args) {
		int x=2;
		System.out.println("x="+x);
		x=(x<<1)+1;
//x=5;
		System.out.println("After shifting 1 bit left,x="+x);

	}

}
