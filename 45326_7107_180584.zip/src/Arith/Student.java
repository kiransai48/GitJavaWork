package Arith;

public class Student {
	
	public String name;
	public int rollno;
	public void display() {
		String title="ABC";
		System.out.print(title);
		System.out.println("kiran");
		title="Roll No.:";
		System.out.print(title);
		System.out.println("50");
		
	}
}
