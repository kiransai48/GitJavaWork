package Arith;

public class Studentdemo {
//method defining
	public static void main(String[] args) {
	 Student s=new Student();
     //method calling   
	 s.display();
	}

}
