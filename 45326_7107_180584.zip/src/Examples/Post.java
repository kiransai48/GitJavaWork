package Examples;

public class Post {
	private String candidateName; 
	 private String candidateGender;
	 private byte age;
	 private float weight;
	 private float height;
	 public String getCandidateName() {
	  return candidateName;
	 }
	 public void setCandidateName(String candidateName) {
	  this.candidateName = candidateName;
	 }
	 public String getCandidateGender() {
	  return candidateGender;
	 }
	 public void setCandidateGender(String candidateGender) {
	  this.candidateGender = candidateGender;
	 }
	 public byte getAge() {
	  return age;
	 }
	 public void setAge(byte age) {
	  this.age = age;
	 }
	 public float getWeight() {
	  return weight;
	 }
	 public void setWeight(float weight) {
	  this.weight = weight;
	 }
	 public float getHeight() {
	  return height;
	 }
	 public void setHeight(float height) {
	  this.height = height;
	 }
}
