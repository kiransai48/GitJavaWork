package Examples;


import java.util.Scanner;
public class Cuberoot {

}
