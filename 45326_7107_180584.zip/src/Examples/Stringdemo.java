package Examples;

public class Stringdemo {
	
	public static void main(String[] args) {
		String s1="Hello";
		String s2="Hello";
		
		
	}

}
