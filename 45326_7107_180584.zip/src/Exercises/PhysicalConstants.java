package Exercises;

public interface PhysicalConstants {
	
	long SPEED_OF_LIGHT_IN_VACCUM=299792458L;
	double GRAVITATIONAL_CONSTANT=6.67428E-11;
	float STANDARD_GRAVITATIONAL_ACCELERATION=9.80665F;

}
