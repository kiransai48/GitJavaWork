package inherit;

public interface Transport {

	String transportName="Public Transport";
	
	public abstract void bookTicket();
	
}
