package inherit;

public class Species {
	private boolean living;
	
	//constructor
	Species()
	{
		living=true;
	}
 
	public void breathe()
	{
		System.out.println("can breathe");
	}
}
