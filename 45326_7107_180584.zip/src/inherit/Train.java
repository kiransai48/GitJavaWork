package inherit;

public class Train implements Transport {
	
	@Override
	public void bookTicket() {
		System.out.println("Train Ticket booked");
		
	}
}
