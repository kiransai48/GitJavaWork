public class ElectronicKeyboard extends Instrument {

	@Override
	public void play() {
		System.out.println("Tin Tin Tinnnnn");
		
	}

}
