import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class Main {

    public static void main(String[] args) throws Exception, IOException {
        InputStreamReader input= new InputStreamReader(System.in);
		BufferedReader b= new BufferedReader(input);
		List<List<Integer>> Li= new ArrayList<List<Integer>>();
		List<Integer> l = new ArrayList<Integer>();
		char c=0;
		System.out.println("Enter the count of booked tickets:");
		for(int i=0;i<5;i++)
		{
			System.out.println("On Day "+(i+1));
			String s= b.readLine();
			String a[]=s.split(",");
			for(int j=0;j<a.length;j++)
			{
				l.add(100-Integer.parseInt(a[j]));
			}
			Li.add(l);
		}
	
		do
		{
			System.out.println("Enter the day to know its remaining ticket count:");
			int n=Integer.parseInt(b.readLine());
			System.out.print("Remaining tickets:[");
			System.out.print(l.get(4*n-4)+", "+l.get(4*n-3)+", "+l.get(4*n-2)+", "+l.get(4*n-1)+"]\n");
			System.out.println("Do you want to continue?(y/n)");
			c=b.readLine().charAt(0);
		}while(c=='y'||c=='Y');

	}

}