import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)
	{
		Scanner scan= new Scanner(System.in);
		List<Address> Li= new ArrayList<Address>();
		System.out.println("Enter the number of users:");
		int n= Integer.parseInt(scan.nextLine());
		System.out.println("Enter user address in CSV(Username,AddressLine 1,AddressLine 2,PinCode)");
		for(int i=0;i<n;i++)
		{
			String add= scan.nextLine();
			String a[]= add.split(",");
			Address ad= new Address(a[0],a[1],a[2],Integer.parseInt(a[3]));
			Li.add(ad);
		}
		Li.sort(null);
		System.out.println("User Details:");
		for (Address address : Li) {
			System.out.println(address);
		}
		
	}
}