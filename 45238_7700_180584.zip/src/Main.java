import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    
	public static void main(String args[])
	{
		List<User> l= new ArrayList<User>();
		Scanner s= new Scanner(System.in);		
		System.out.println("Enter the number of users:");
		int m= Integer.parseInt(s.nextLine());
		for(int i=0;i<m;i++)
		{
			System.out.println("User"+(i+1)+"\r\nName:");
			String name= s.nextLine();
			System.out.println("contact number:");
			String connum= s.nextLine();
			User u= new User(name, connum);
			l.add(u);
		}
		System.out.println("Enter the number of halls:");
		int n2= Integer.parseInt(s.nextLine());
		User user= new User();
		for(int i=0;i<n2;i++)
		{
			System.out.println("Hall"+(i+1)+"\r\nName:");
			String hn= s.nextLine();
			System.out.println("Cost per day:");
			int hc= Integer.parseInt(s.nextLine());
			System.out.println("Owner Name:");
			String ho= s.nextLine();
			Hall h= new Hall(hn, hc, ho);
			user.addToHallList(h);
		}				
		for (User u : l) {
			System.out.println("Owner Name:"+u.getName());
			user.checkOwner(u.getName());			
		}
	}
}
